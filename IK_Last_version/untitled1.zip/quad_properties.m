% Biped Properties
global L1 L2 L3 L4
%% Length OK
L1= [53.26 61.84 0.1]/1000; % Length of hip
L2= 201/1000; % Length of hind thigh  [0 46.5 201]
L3= 246.5/1000; % Length of middle hind thigh [0 63.5 246.5]
L4=[77.18 145 280.52]/1000; % Length of shank
