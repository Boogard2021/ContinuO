%% Redundancy Resolution
clear all;
close all;
clc;

global lower_joint_limits upper_joint_limits
run quad_properties
color_list = {'blue', 'red','green', 'black'};

p_global = [-130.44 -206.84 -728.12]'/1000;  % zero position
% p_global = [-130.61 -205.84 -620.05]'/1000;
% p_global = [-226.55 -153.84 -463.83]'/1000;

offset_y = 145/1000;
delta_y = -p_global(2);
delta_z = abs(-p_global(3));

h = sqrt(delta_y^2+delta_z^2);
q1= -atan2(delta_y,delta_z)+asin((L1(2)+offset_y)/h);
% r_0 = sqrt(delta_y^2+delta_z^2-L1(2)^2);
% Pos_0 = FK(q_0);
% clf;
% view(3)
% Visualize_Robot(Pos_0, p_global, color_list)
% pause(0.1);
lower_joint_limits = [-1.2,-1.2,-2.4,-2]';
upper_joint_limits = [1.2,1.2,+2.4,2]';
alpha = 0*pi/180;
% alpha = -20*pi/180:pi/180:20*pi/180; % alpha= -(q2+q3+q4);
j=1;
for i=1:length(alpha)
    knee(:,i) = Knee_pos(p_global,alpha(i));
    dy(i)=abs(-knee(2,i));
    dz(i)=abs(-knee(3,i));
    q_ = angle_joints(q1,knee(:,i),dy(i),dz(i));
    q2 = q_(1);
    q3 = q_(2);
    q4= -q2-q3-alpha(i);
    q= [q1 q2 q3 q4]';
    q_deg= [q1 q2 q3 q4]'*180/pi;
    if check_security(q)==1
        q_new(:,j) = [q1 q2 q3 q4 alpha(i)]';
        Pos(:,j) = FK(q_new(:,j)); %q_new
        ankle_pos =Pos(13:15,j);
        error(j)=(1/3)*sum((ankle_pos-p_global).^2);
        j = j+1;
    else
        continue
    end
end
% figure
% plot(error)
figure
view(3)
Visualize_Robot(Pos, p_global, color_list) %Pos(:,3)
pause(0.1);

